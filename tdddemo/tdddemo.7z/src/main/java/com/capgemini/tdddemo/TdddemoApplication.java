package com.capgemini.tdddemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TdddemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TdddemoApplication.class, args);
	}

}
